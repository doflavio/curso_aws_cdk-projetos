package br.gov.github.doflavio.aws_project02;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AwsProject02ApplicationTests {

	@Test
	void contextLoads() {
	}

}
