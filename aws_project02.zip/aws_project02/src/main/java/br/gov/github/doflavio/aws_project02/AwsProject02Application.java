package br.gov.github.doflavio.aws_project02;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AwsProject02Application {

	public static void main(String[] args) {
		SpringApplication.run(AwsProject02Application.class, args);
	}

}
